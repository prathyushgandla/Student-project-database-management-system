// JavaScript Document
 
  $(document).ready(function(){
  	"use strict";
	  $('.post-slider').slick({
	  	autoplay: true,
 			});
	});