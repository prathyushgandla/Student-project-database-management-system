from django.contrib import admin

from collegeproject.models import Project, Student

# Register your models here.
admin.site.register(Project)
admin.site.register(Student)
