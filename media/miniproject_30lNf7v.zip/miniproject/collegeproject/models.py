from django.db import models

# Create your models here.
class Project(models.Model):
    academic=models.CharField(null=True, blank=True,max_length=100)
    project_type=models.CharField(null=True, blank=True,max_length=100)
    department=models.CharField(null=True, blank=True,max_length=100)
    group_size=models.IntegerField(null=True, blank=True)
    title=models.CharField(null=True, blank=True,max_length=100)
    stu_name1=models.CharField(null=True, blank=True,max_length=100)
    stu_rollno1=models.CharField(null=True, blank=True,max_length=100)
    stu_name2=models.CharField(null=True, blank=True,max_length=100)
    stu_rollno2=models.CharField(null=True, blank=True,max_length=100)
    stu_name3=models.CharField(null=True, blank=True,max_length=100)
    stu_rollno3=models.CharField(null=True, blank=True,max_length=100)
    stu_name4=models.CharField(null=True, blank=True,max_length=100)
    stu_rollno4=models.CharField(null=True, blank=True,max_length=100)
    stu_name5=models.CharField(null=True, blank=True,max_length=100)
    stu_rollno5=models.CharField(null=True, blank=True,max_length=100)
    research=models.TextField(null=True, blank=True)
    software=models.TextField(null=True, blank=True)
    guide=models.CharField(null=True, blank=True,max_length=100)
    def __str__(self):
        return self.title
class Student(models.Model):
    student=models.CharField(null=True, blank=True,max_length=100)
    rollno=models.CharField(null=True, blank=True,max_length=100)
    def __str__(self):
        return self.student