from django.shortcuts import render,redirect
from .models import Project,Student
import re
from django.contrib import messages

# Create your views here.
def createProject(request):
    if request.method == 'POST' :
        academic=request.POST.get('academic')
        project_type=request.POST.get("project-type")
        department=request.POST.get("department")
        size1=request.POST.get("size")
        size=int(size1)
        title=request.POST.get("title")
        st_roll1=request.POST.get("st-rno1")
        st_name1=request.POST.get("st-name1")
        st_roll2=request.POST.get("st-rno2")
        st_name2=request.POST.get("st-name2")
        st_roll3=request.POST.get("st-rno3")
        st_name3=request.POST.get("st-name3")
        st_roll4=request.POST.get("st-rno4")
        st_name4=request.POST.get("st-name4")
        st_roll5=request.POST.get("st-rno5")
        st_name5=request.POST.get("st-name5")
        research=request.POST.get("research")
        software=request.POST.get("software")
        guide=request.POST.get("guide")
        id_regex="(\\d{2}).*(\\d{3})"
        name_regex="^[a-zA-Z ]*$"
        st_rollno=[st_roll1,st_roll2,st_roll3,st_roll4,st_roll5]
        st_names=[st_name1,st_name2,st_name3,st_name4,st_name5]
        if size==4:
            if st_roll4=='' or st_name4=='':
                messages.info(request,'Student4 Name and Id required')
                return redirect('createproject')
        if size==5:
            if st_roll5=='' or st_name5=='':
                messages.info(request,'Student5 Name and Id required')
                return redirect('createproject')
        if(len(st_name1)==0 or len(st_name1)>8 and len(st_roll1)==0 or len(st_roll1)==10):
            if(len(st_name2)==0 or len(st_name2)>8 and len(st_roll2)==0 or len(st_roll2)==10):
                if(len(st_name3)==0 or len(st_name3)>8 and len(st_roll3)==0 or len(st_roll3)==10):
                    if(len(st_name4)==0 or len(st_name4)>8 and len(st_roll4)==0 or len(st_roll4)==10):
                        if(len(st_name5)==0 or len(st_name5)>8 and len(st_roll5)==0 or len(st_roll5)==10):
                            for i in st_names:
                                if(Project.objects.filter(stu_name1=i.title()).exists() or 
                                    Project.objects.filter(stu_name2=i.title()).exists() or 
                                    Project.objects.filter(stu_name3=i.title()).exists()):
                                    messages.info(request,'Student Exist')
                                    return redirect('createproject')
                            for j in st_rollno:
                                if(Project.objects.filter(stu_rollno1=j.upper()).exists() or
                                    Project.objects.filter(stu_rollno2=j.upper()).exists() or
                                    Project.objects.filter(stu_rollno3=j.upper()).exists()):
                                    messages.info(request,'Student Id Exist')
                                    return redirect('createproject')
                            for i in st_rollno:
                                if len(i)!=0:
                                    if bool(re.search(id_regex,i))==True:
                                        id_res='True'
                                    else:
                                        messages.info(request,'Invalid Student Id')
                                        return redirect('createproject')
                            for j in st_names:
                                if len(j)!=0:
                                    if bool(re.search(name_regex,j))==True:
                                        name_res='True'
                                    else:
                                        messages.info(request,'Invalid Student Name')
                                        return redirect('createproject')
                            if bool(re.search(name_regex,guide))==True:
                                guide_res='True'
                            else:
                                messages.info(request,'Invalid Guide Name')
                                return redirect('createproject')
                            if id_res=='True' and name_res=='True' and guide_res=='True':
                                Project.objects.create(academic=academic,
                                project_type=project_type,
                                department=department,
                                group_size=size,
                                title=title.title(),
                                stu_name1=st_name1.title(),
                                stu_rollno1=st_roll1.upper(),
                                stu_name2=st_name2.title(),
                                stu_rollno2=st_roll2.upper(),
                                stu_name3=st_name3.title(),
                                stu_rollno3=st_roll3.upper(),
                                stu_name4=st_name4.title(),
                                stu_rollno4=st_roll4.upper(),
                                stu_name5=st_name5.title(),
                                stu_rollno5=st_roll5.upper(),
                                research=research,
                                software=software,
                                guide=guide.title())
                                return redirect('home')
        messages.info(request,'Student name must contain atleast 8 characters and Student Id must contain 10 characters')
        return redirect('createproject')
    return render(request, 'form.html')


def update(request,id1):
    project = Project.objects.get(id=id1)
    if request.method == 'POST':
        project.project_type=request.POST.get("project-type")
        project.department=request.POST.get("department")
        project.size1=request.POST.get("size")
        size=int(project.size1)
        project.title=request.POST.get("title").title()
        project.stu_roll1=request.POST.get("st-rno1").upper()
        project.stu_name1=request.POST.get("st-name1").title()
        project.stu_roll2=request.POST.get("st-rno2").upper()
        project.stu_name2=request.POST.get("st-name2").title()
        project.stu_roll3=request.POST.get("st-rno3").upper()
        project.stu_name3=request.POST.get("st-name3").title()
        project.stu_roll4=request.POST.get("st-rno4").upper()
        project.stu_name4=request.POST.get("st-name4").title()
        project.stu_roll5=request.POST.get("st-rno5").upper()
        project.stu_name5=request.POST.get("st-name5").title()
        project.research=request.POST.get("research")
        project.software=request.POST.get("software")
        project.guide=request.POST.get("guide").title()
        id_regex="(\\d{2}).*(\\d{3})"
        name_regex="^[a-zA-Z ]*$"
        st_rollno=[project.stu_roll1,project.stu_roll2,project.stu_roll3,project.stu_roll4,project.stu_roll5]
        st_names=[project.stu_name1,project.stu_name2,project.stu_name3,project.stu_name4,project.stu_name5]
        if size==4:
            if project.st_roll4=='' or project.st_name4=='':
                messages.info(request,'Student4 Name and Id required')
                return redirect('createproject')
        if size==5:
            if project.st_roll5=='' or project.st_name5=='':
                messages.info(request,'Student5 Name and Id required')
                return redirect('createproject')
        if len(project.stu_roll1)==0 or len(project.stu_roll1)==10 and len(project.stu_name1)==0 or len(project.stu_name1)>8:
            if len(project.stu_roll2)==0 or len(project.stu_roll2)==10 and len(project.stu_name2)==0 or len(project.stu_name3)>8:
                if len(project.stu_roll3)==0 or len(project.stu_roll3)==10 and len(project.stu_name3)==0 or len(project.stu_name3)>8:
                    if len(project.stu_roll4)==0 or len(project.stu_roll4)==10 and len(project.stu_name4)==0 or len(project.stu_name4)>8:
                        if len(project.stu_roll5)==0 or len(project.stu_roll5)==10 and len(project.stu_name5)==0 or len(project.stu_name5)>8:
                            for i in st_rollno:
                                if len(i)!=0:
                                    if bool(re.search(id_regex,i))==True:
                                        id_res='True'
                                    else:
                                        messages.info(request,'Invalid Student Id')
                                        return redirect('createproject')
                            for j in st_names:
                                if len(j)!=0:
                                    if bool(re.search(name_regex,j))==True:
                                        name_res='True'
                                    else:
                                        messages.info(request,'Invalid Student Name')
                                        return redirect('createproject')
                            if bool(re.search(name_regex,project.guide))==True:
                                guide_res='True'
                            else:
                                messages.info(request,'Invalid Guide Name')
                                return redirect('createproject')
                            if id_res=='True' and name_res=='True' and guide_res=='True':
                                project.save()
                                return redirect('home')
        messages.info(request,'Student Id must contain 10 characters and Name must contain atleast 8 characters')
        return redirect('createproject')
    return render(request,'form.html',{'project':project})
def home(request):
    project=Project.objects.filter()
    context={'project':project}
    return render(request, 'home.html',context)
def data(request,id):
    project = Project.objects.get(id=id)
    context = {'project': project }
    return render(request,'data.html',context)
def delete(request,id2):
    project = Project.objects.get(id=id2)
    project.delete()
    return redirect('home')
def search(request):
    if request.method=='POST':
        search=request.POST.get('search')
        titles=Project.objects.filter(title__icontains=search)
        context={'titles':titles,'search':search}
        return render(request,'search.html',context)
    else:
        return render(request,'search.html')